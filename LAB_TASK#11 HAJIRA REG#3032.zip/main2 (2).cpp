/*#include<iostream>
int Sum_digits(int n);
int main()
{
	int n;
	std::cout << "enter value ";
	std::cin >> n;
	int sum;
	sum = Sum_digits(n);
	std::cout <<"SUM IS "<< sum;
}
int Sum_digits(int n)
{
	int d1=0, d2=0;
	if (n > 0)
	{
		d1 = n % 10;
		d2 = n / 10;
		return (d1 + Sum_digits(d2));
	}
	else
	{
		return 0;
	}
}*/