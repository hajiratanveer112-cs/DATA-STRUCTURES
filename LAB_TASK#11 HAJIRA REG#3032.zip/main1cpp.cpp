/*#include<iostream>
int Sum_natnum(int n);
int main()
{
	int n,sum;
	std::cout << "enter a  number ";
	std::cin >> n;
	sum=Sum_natnum(n);
	std::cout << "sum of  numbers is " << sum;
	return 0;
}
int Sum_natnum(int n)
{
	if (n > 0)
	{
		return n + Sum_natnum(n - 1);
	}
	else
	{
		return 0;
	}
}*/