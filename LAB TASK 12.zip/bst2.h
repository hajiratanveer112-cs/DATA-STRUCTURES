#pragma once
#include<iostream>
template<typename T>
class bst
{
private:
	template<typename T>
	struct node
	{
		T val;
		node<T>* left, * right, * parent;
	};
	node <T>* head;
	int n;
public:
	class iterator
	{
	private:
		node<T>*ptr;
		friend class bst;
	public:

		T& operator*()
		{
			return this->ptr->val;

		}
		T* operator->()
		{
			return this->ptr;
		}

	};
	bst()
	{
		head = new node<T>;
		head->left =head;
		head->right = head;
		head->parent = head;
		n = 0;
	}
	void Insert(const T& val)
	{
		node<T>* temp;
		temp = new node<T>;
		temp->val = val;
		temp->left = head;
		temp->right = head;
		if (head->parent == head)
		{
			head->parent = temp;
			temp->parent = head;
			head->left = temp;
			head->right = temp;
			++n;
		}
		else
		{
			node<T>* ptr;
			ptr = head->parent;
			while (true)
			{
				if (val > ptr->val)
				{
					if (ptr->right == head)
					{
						ptr->right = temp;
						temp->parent = ptr;
						if (head->right->val < temp->val)
						{
							head->right = temp;
						}
						++n;
						return;
					}
					else
					{
						ptr = ptr->right;
					}
				}
				else
				{
					if (val < ptr->val)
					{
						if (ptr->left == head)
						{
							ptr->left = temp;
							temp->parent = ptr;
							if (head->left->val > temp->val)
							{
								head->left = temp;
							}
							++n;
							return;
						}
						else
						{
							ptr = ptr->left;
						}
					}
				}
			}
		}
	}
	bool Contains(const T& val)const
	{
		node<T>* ptr;
		ptr = head->parent;
		while (ptr !=head)
		{
			if (val == ptr->val)
			{
				return true;
			}
			else if (val < ptr->val)
			{
				ptr = ptr->left;
			}
			else
			{
				ptr = ptr->right;
			}
		}
		return false;
	}
	bool empty()const
	{
		if (head->parent == head)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	int size()const
	{
		return n;
	}
};