#include"bst2.h"
int main()
{
	bst<int>t1;
	t1.Insert(9);
	t1.Insert(11);
	std::cout << t1.Contains(11) << " ";
	std::cout << t1.size();
}