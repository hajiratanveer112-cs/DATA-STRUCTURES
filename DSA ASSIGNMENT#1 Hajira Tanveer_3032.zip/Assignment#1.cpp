#include<iostream>
#include<chrono>
#include<list>
#include<vector>
#include<forward_list>
#include<cstdlib>
#include<algorithm>
#include<ctime>
#include"ass1.h"
void Push_values_in_vector_ascending(std::vector<int>&A);
void Push_values_in_vector_descending(std::vector<int>& B);
void Push_values_in_vector_random(std::vector<int>& C);
void Push_values_in_forwardlist_asc(std::forward_list<int>& A_for_list);
void Push_values_in_forwardlist_desc(std::forward_list<int>& B_for_list);
void Push_values_in_forwardlist_rand(std::forward_list<int>& C_for_list);
void Push_values_in_list_asc(std::list<int>& A_list);
void Push_values_in_list_des(std::list<int>& B_list);
void Push_values_in_list_rand(std::list<int>& C_list);
void Sort_vector(std::vector<int>& vector)
{
	std::sort(vector.begin(), vector.end());
}
void Sort_forwardlist(std::forward_list<int>&forward_list)
{
	forward_list.sort();
}
void Sort_list(std::list<int>&list)
{
list.sort();
}
int main()
{
	Sorting vec;
	srand(time(0));
	std::vector<int>A_vec,B_vec,C_vec,E_vec,F_vec,G_vec;
	std::forward_list<int>A_for_list,B_for_list,C_for_list,E_for_list,F_for_list,G_for_list;
	std::list<int>A_list, B_list, C_list,E_list, F_list, G_list;
	std::cout << "INSERTING AND STORING VALUES IN VECTOR CONTAINERS "  << '\n';
	auto start=std::chrono::steady_clock::now() ;
	auto finish=std::chrono::steady_clock::now() ;
	std::chrono::duration<double> elapsed_seconds;
	start = std::chrono::steady_clock::now();
	 Push_values_in_vector_ascending(A_vec);
 finish=std::chrono::steady_clock::now() ;
	elapsed_seconds=finish - start;
	std::cout << "Time measurement while inserting values in vector in ascending order = " << elapsed_seconds << '\n';
 start=std::chrono::steady_clock::now();
	 Push_values_in_vector_descending(B_vec);
	 finish= std::chrono::steady_clock::now() ;
 elapsed_seconds= finish - start;
	std::cout << " Time measurement while inserting values in vector in descending order =  " << elapsed_seconds << '\n';
	start= std::chrono::steady_clock::now();
	Push_values_in_vector_random(C_vec);
 finish=std::chrono::steady_clock::now();
 elapsed_seconds=finish - start;
std::cout << " Time measurement while inserting values in vector in random order = " <<  elapsed_seconds << '\n';
	std::cout << "INSERTING AND STORING VALUES IN FORWARD_LIST CONTAINER " << "\n";
	 start=std::chrono::steady_clock::now() ;
	Push_values_in_forwardlist_asc(A_for_list);
	 finish=std::chrono::steady_clock::now();
 elapsed_seconds= finish - start;
	std::cout <<"Time measurement while inserting values in forward_list in ascending order = "  << elapsed_seconds << '\n';
	 start= std::chrono::steady_clock::now() ;
	Push_values_in_forwardlist_desc(B_for_list);
	 finish=std::chrono::steady_clock::now() ;
	 elapsed_seconds=finish - start ;
	std::cout << "Time measurement while inserting values in forward_list in descending order = " << elapsed_seconds << '\n';
 start=std::chrono::steady_clock::now() ;
	Push_values_in_forwardlist_rand(C_for_list);
	finish=std::chrono::steady_clock::now() ;
	elapsed_seconds= finish - start ;
	std::cout << "Time measurement while inserting values in forward_list in random  order = " << elapsed_seconds<< '\n';
	std::cout << "INSERTING AND STORING VALUES IN LIST CONTAINER " << "\n";
start = std::chrono::steady_clock::now();
	Push_values_in_list_asc(A_list);
	finish=std::chrono::steady_clock::now() ;
	 elapsed_seconds=finish - start;
	std::cout << " Time measurement while inserting values in list in ascending  order =  "  << elapsed_seconds << '\n';
	 start=std::chrono::steady_clock::now() ;
	Push_values_in_list_des(B_list);
 finish=std::chrono::steady_clock::now() ;
	 elapsed_seconds=finish - start;
	std::cout << " Time measurement while inserting values in list in descending  order = "  << elapsed_seconds << '\n';
	 start=std::chrono::steady_clock::now();
	Push_values_in_list_rand(C_list);
 finish=std::chrono::steady_clock::now();
	 elapsed_seconds=finish - start;
	std::cout << " Time measurement while inserting values in list in random  order = "  << elapsed_seconds << '\n';
std::cout << "SORTING VECTOR AND MEASURING TIME(USING STL SORT)" << '\n';
start=std::chrono::steady_clock::now() ;
	Sort_vector(A_vec);
 finish=std::chrono::steady_clock::now() ;
elapsed_seconds=finish- start;
	std::cout << "Time measurement while sorting values in A(ascending) = "  << elapsed_seconds << '\n';
	 start=std::chrono::steady_clock::now() ;
		Sort_vector(B_vec);
	 finish=std::chrono::steady_clock::now() ;
	 elapsed_seconds=finish- start ;
		std::cout << "Time measurement while sorting values in B(descending) = " << elapsed_seconds << '\n';
 start= std::chrono::steady_clock::now() ;
		Sort_vector(C_vec);
		 finish= std::chrono::steady_clock::now() ;
		 elapsed_seconds=finish - start ;
	std::cout << "Time measurement while sorting values in C(random) = "  << elapsed_seconds << '\n';

	std::cout << "SORTING VECTOR USING MY HEAPSORT AND MEASURING TIME " << '\n';
	start = std::chrono::steady_clock::now();
	vec.myHeapSort(A_vec);
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Time measurement while sorting vector A (ascending) usng heapsort = "  << elapsed_seconds << '\n';

	start = std::chrono::steady_clock::now();
	vec.myHeapSort(B_vec);
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Time measurement while sorting vector B (descending) usng heapsort = "  << elapsed_seconds << '\n';
	start = std::chrono::steady_clock::now();
	vec.myHeapSort(C_vec);
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Time measurement while sorting vector C(random) usng heapsort = " << elapsed_seconds << '\n';
std::cout << "SORTING FORWARD_LIST AND MEASURING TIME(USING ITS MEMBER FUNCTION)" << '\n';
	 start =std::chrono::steady_clock::now() ;
		Sort_forwardlist(A_for_list);
	 finish=std::chrono::steady_clock::now() ;
 elapsed_seconds=finish - start;
		std::cout << " Time measurement while sorting values in A(ascending) = "  << elapsed_seconds << '\n';
		 start= std::chrono::steady_clock::now() ;
		Sort_forwardlist(B_for_list);
		 finish=std::chrono::steady_clock::now();
	elapsed_seconds=finish - start ;
		std::cout << " Time measurement while sorting values in B(descending) = "<< elapsed_seconds << '\n';
		 start= std::chrono::steady_clock::now() ;
		Sort_forwardlist(C_for_list);
		 finish=std::chrono::steady_clock::now() ;
	 elapsed_seconds=finish - start ;
		std::cout<< " Time measurement while sorting values in C(random) = "  << elapsed_seconds << '\n';
std::cout << "SORTING LIST AND MEASURING TIME(USING ITS MEMBER FUNCTION)" << '\n';
		 start=std::chrono::steady_clock::now() ;
		Sort_list(A_list);
		 finish=std::chrono::steady_clock::now();
 elapsed_seconds=finish- start;
		std::cout << "Time measurement while sorting values in A(ascending) =   "  << elapsed_seconds << '\n';
	 start= std::chrono::steady_clock::now() ;
		Sort_list(B_list);
	 finish= std::chrono::steady_clock::now();
	 elapsed_seconds=finish - start;
		std::cout << "Time measurement while sorting values in B(descending) =   " << elapsed_seconds << '\n';
	start= std::chrono::steady_clock::now() ;
		Sort_list(C_list);
	finish= std::chrono::steady_clock::now() ;
	elapsed_seconds= finish - start ;
		std::cout << "Time measurement while sorting values in C(random) =   " << elapsed_seconds << '\n';

		std::cout << "INSERTING VALUES IN VECTOR E F AND G ";
		start = std::chrono::steady_clock::now();
		Push_values_in_vector_ascending(E_vec);
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << "Time measurement while inserting values in A(ascending) " << elapsed_seconds << '\n';

		start = std::chrono::steady_clock::now();
		Push_values_in_vector_descending(F_vec);
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << "Time measurement while inserting values in B(descending) "  << elapsed_seconds << '\n';
		
		start = std::chrono::steady_clock::now();
		Push_values_in_vector_random(G_vec);
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << "Time measurement while inserting values in C(random) = " << elapsed_seconds << '\n';
		std::cout << "INSERTING VALUES IN FORWARD_LIST E F AND G ";
		start = std::chrono::steady_clock::now();
		Push_values_in_forwardlist_asc(E_for_list);
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << "Time measurement while inserting values in A(ascending) = "   << elapsed_seconds << '\n';

		start = std::chrono::steady_clock::now();
		Push_values_in_forwardlist_desc(F_for_list);
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << "Time measurement while inserting values in B(descending) " << elapsed_seconds << '\n';

		start = std::chrono::steady_clock::now();
		Push_values_in_forwardlist_rand(G_for_list);
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << " Time measurement while inserting values in C(random) = " << elapsed_seconds << '\n';
		std::cout << "INSERTING VALUES IN LIST E F AND G ";
		start = std::chrono::steady_clock::now();
		Push_values_in_list_asc(E_list);
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << " Time measurement while inserting values in A(ascending) = " << elapsed_seconds << '\n';

		start = std::chrono::steady_clock::now();
		Push_values_in_list_des(F_list);
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << "Time measurement while inserting values in B(descending) = " << elapsed_seconds << '\n';



		start = std::chrono::steady_clock::now();
		Push_values_in_list_rand(G_list);
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << "  Time measurement while inserting values in C(random) = " << elapsed_seconds << '\n';

		std::cout << "ERASING FROM E F AND G " << '\n';
		start = std::chrono::steady_clock::now();
		std::erase_if(E_vec, [](int x)->bool{return x % 2==1; });
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << " Erasing values in vector  E  \n " << "elapsed time = " << elapsed_seconds << '\n';

		start = std::chrono::steady_clock::now();
		std::erase_if(F_vec, [](int x)->bool {return x % 2 == 1; });
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << " Erasing values in vector F  \n " << "elapsed time = " << elapsed_seconds << '\n';

		start = std::chrono::steady_clock::now();
		std::erase_if(G_vec, [](int x)->bool {return x % 2 == 1; });
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << " Erasing values in vector G  \n " << "elapsed time = " << elapsed_seconds << '\n';

		//SORTING VECTOR  USING MY SORT
		start = std::chrono::steady_clock::now();
		vec.mySort(E_vec, E_vec.size());
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << " Sorting values in E " << "elapsed time = " << elapsed_seconds << '\n';



		start = std::chrono::steady_clock::now();
		vec.mySort(F_vec, F_vec.size());
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << " Sorting values in F " << "elapsed time = " << elapsed_seconds << '\n';

		start = std::chrono::steady_clock::now();
		vec.mySort(G_vec, G_vec.size());
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << " Sorting values in G " << "elapsed time = " << elapsed_seconds << '\n';

		start = std::chrono::steady_clock::now();
		std::erase_if(E_for_list, [](int x)->bool {return x % 2 == 1; });
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << " Erasing values in Forward_list E  \n " << "elapsed time = " << elapsed_seconds << '\n';

		start = std::chrono::steady_clock::now();
		std::erase_if(F_for_list, [](int x)->bool {return x % 2 == 1; });
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << " Erasing values in   Forward_list F  \n " << "elapsed time = " << elapsed_seconds << '\n';

		start = std::chrono::steady_clock::now();
		std::erase_if(G_for_list, [](int x)->bool {return x % 2 == 1; });
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << " Erasing values in  Forward_list G \n " << "elapsed time = " << elapsed_seconds << '\n';

		start = std::chrono::steady_clock::now();
		std::erase_if(E_list, [](int x)->bool {return x % 2 == 1; });
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << " Erasing values in list E  \n " << "elapsed time = " << elapsed_seconds << '\n';



		start = std::chrono::steady_clock::now();
		std::erase_if(F_list, [](int x)->bool {return x % 2 == 1; });
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << " Erasing values in list F  \n " << "elapsed time = " << elapsed_seconds << '\n';


		start = std::chrono::steady_clock::now();
		std::erase_if(G_list, [](int x)->bool {return x % 2 == 1; });
		finish = std::chrono::steady_clock::now();
		elapsed_seconds = finish - start;
		std::cout << " Erasing values in list G  \n " << "elapsed time = " << elapsed_seconds << '\n';


		return 0;
}
void Push_values_in_vector_ascending(std::vector<int>& A)
{
	int i;
	for (i = 1; i <= 100000; ++i)
	{
		A.push_back(i);
	}
}
void Push_values_in_vector_descending(std::vector<int>& B)
{
	int i;
	for (i = 100000; i >= 1; --i)
	{
		B.push_back(i);
	}
}
void Push_values_in_vector_random(std::vector<int>& C)
{
	int i,val;
	for (i = 1; i <= 100000; ++i)
	{
		val = rand() % 100000 + 1;
		C.push_back(val);
	}
}
void Push_values_in_forwardlist_asc(std::forward_list<int>& A_for_list)
{

	std::forward_list<int>::iterator it;
	it = A_for_list.before_begin();
	int i;
	for (i = 1; i <= 100000; ++i)
	{
		it=A_for_list.insert_after(it, i);
	}
	
}
void Push_values_in_forwardlist_desc(std::forward_list<int>& B_for_list)
{
	std::forward_list<int>::iterator it;
	it = B_for_list.before_begin();
	int i;
	for (i = 100000; i >=1; --i)
	{
		it = B_for_list.insert_after(it, i);
	}
}
void Push_values_in_forwardlist_rand(std::forward_list<int>& C_for_list)
{
	std::forward_list<int>::iterator it;
	it = C_for_list.before_begin();
	int i,val;
	for (i = 1; i<=100000; ++i)
	{
		val=rand() % 100000 + 1;
		it = C_for_list.insert_after(it,val);
	}
}
void Push_values_in_list_asc(std::list<int>& A_list)
{
	int i;
	for (i = 1; i <= 100000; ++i)
	{
		A_list.push_back(i);
	}
}
void Push_values_in_list_des(std::list<int>& B_list)
{
	int i;
	for (i = 100000; i>=1; --i)
	{
		B_list.push_back(i);
	}
}
void Push_values_in_list_rand(std::list<int>& C_list)
{
	int i,val;
	for (i = 1; i <=100000; ++i)
	{
		val = rand() % 100000 + 1;
		C_list.push_back(val);
	}
}


