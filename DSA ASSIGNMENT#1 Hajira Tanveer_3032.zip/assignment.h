#pragma once
#include<iostream>
#include<vector>
class Sorting {
public:
	void mySort(std::vector<int>&A,int n)
	{
		int i, j,num;
		for (i = 1; i < n; ++i)
		{
			num = A[i];
			for (j = i-1; j >= 0; --j)
			{
				if (num < A[j])
				{
					A[j + 1] = A[j];
				}
				else
				{
					break;
				}
			}
			A[j + 1] = num;
		}
	}
	void myHeapSort(std::vector<int>& A)
	{
		int i;
		for (i = (A.size() / 2) - 1; i >=0; --i)
		{
			Reheapdown(A, i, A.size() - 1);

		}
		for (i = A.size() - 1; i > 0; --i)
		{
			std::swap(A[0], A[i]);
			Reheapdown(A, 0, i - 1);
		}
	}
	void Reheapdown(std::vector<int>&A, int first,int last)
	{
		int l, r, m;
		l = first * 2 + 1;
		r = first * 2 + 2;
		m = l;
		while (l <= last)
		{
			if (r <= last)
			{
				if (A[r] >A[l])
				{
					m = r;
				}
			}
			if (A[first] < A[m])
			{
				std::swap(A[first], A[m]);
				first = m;
				l = first * 2 + 1;
				r = first * 2 + 2;
				m = l;
			}
			else
			{
				break;
			}
		}
	}
};